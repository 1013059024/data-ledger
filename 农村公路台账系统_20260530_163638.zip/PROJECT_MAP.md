# 农村公路台账系统 — 完整项目地图

> **任何新功能接入前必读！改动旧功能前必读！**
> 此文档记录项目的每一处细节。新增任何功能后必须同步更新此文档。

---

## 1. 项目结构

```
E:\reasonix-data\projects\road-ledger/
├── server/                          # 后端主目录
│   ├── app.py                       # Flask 应用（所有 API 路由 + 业务逻辑）
│   ├── config.py                    # 数据库连接配置 + Flask Secret
│   ├── db.py                        # 数据库操作层（查询/写入/建表等）
│   ├── push_github.py               # GitHub 推送脚本
│   ├── requirements.txt             # Python 依赖
│   ├── templates/
│   │   ├── index.html               # 前端页面（全部 HTML + JS + CSS 内嵌）
│   │   └── index.html.bak_070905    # 备份
│   ├── static/css/style.css         # 自定义样式
│   ├── _backup/                     # 删表自动备份目录
│   │   └── _manifest.json           # 表结构元数据
│   ├── _hidden_columns.json         # 隐藏列配置
│   ├── _key_fields.json             # 关键字段配置
│   ├── _sync_mappings.json          # 同步映射配置
│   └── _table_groups.json           # 表分组配置
├── mysql-data/                      # MySQL 数据目录（8.4.4）
│   └── road_ledger/                 # 业务数据库（3 张表）
├── start.py                         # 一键启动（MySQL + Flask）
├── start.bat                        # 批处理启动器
├── build_portable.py                # 打包便携版
├── 260529zongbiao.json              # 全量数据导出（备份）
├── 农村公路台账_备份_20260528_224431.json  # 全量数据导出（备份）
└── PROJECT_MAP.md                   # 本文件
```

---

## 2. 导航栏（navbar）

`index.html` 顶部深蓝导航条，固定顶部（`fixed-top`）。

| 元素 | ID | 显示 | 行号 | 功能 |
|------|----|------|------|------|
| 品牌 | - | 🛣️ 农村公路台账 | 13 | 首页链接 |
| 表计数 | `#tableCount` | 0 张表 | 13 | 加载时更新 |
| 保存状态 | `#saveStatus` | ✅ 已保存 / ⏳ 保存中 / ✏️ 编辑中 | 13 | AJAX 状态自动切换 |
| 映射 | `#syncBtn` | 🔗 映射 | 15 | 打开同步映射管理 |
| 导入 | `#uploadBtn` | 📤 导入 | 16 | 打开上传 Modal（Excel→建表） |
| 备份 | `#backupManageBtn` | 💾 备份 | 17 | 打开数据库备份/恢复弹窗 |

---

## 3. 侧边栏（sidebar）

固定宽度 #sidebar，左侧竖排。

| 元素 | ID / 类 | 功能 |
|------|----------|------|
| ＋新建 | `#createTableBtn` | 弹出 `#createTableModal` |
| ⚙️ | `#groupManageBtn` | 弹出 `#groupModal` 管理表分组 |
| 表列表 | `#tableList` | 渲染后的表名列表，含分组折叠 |

---

## 4. 表格视图（tableView）

| 元素 | ID | 显示 | 说明 |
|------|----|------|------|
| 表名 | `#tableName` | - | 当前表名 |
| 重命名 | `#renameTableBtn` | ✏️ | 弹出重命名 Modal |
| 删除 | `#deleteTableBtn` | 🗑️ | 弹出删除确认 |
| 记录数 | `#totalRecords` | - | 文本：总记录数 |
| 关键字段 | `#keyFieldDisplay` | 🔑 — | 当前表关键字段名 |
| 隐藏行徽章 | `#hiddenBadge` | 👁 已隐藏 N 条 | 点击弹出隐藏行列表 |
| 表删徽章 | `#deletedBadge` | 🗃 表删 N 条 | 点击弹出表删除记录 |
| 数据库 | `#dbViewBtn` | 🗄 数据库 | 查看所有数据库记录 |
| 备份徽章 | `#backupBadge` | 🗑 N | 已删除表备份（_backup/ 目录） |
| 搜索框 | `#searchInput` | - | 搜索当前表 |
| 导出 | `#exportBtn` | 📥 导出 | 导出当前表为 Excel |
| 列功能 | `#colFuncBtn` | 📋 列功能 | 打开列功能 Modal |
| 补填 | `#backfillBtn` | 📥 补填 | 打开补填 |
| 多表合一 | `#aggregateBtn` | 📊 多表合一 | 汇总表 |
| 分类汇总 | `#groupSummaryBtn` | 📊 分类汇总 | 打开分类汇总 |
| 刷新 | `#refreshBtn` | 🔄 | 刷新当前表数据 |

---

## 5. 所有模态框（Modal）详细说明

### 5.1 `#uploadModal` — 📤 选择文件
- 行号：43-49
- 用途：选择 Excel 文件（.xlsx/.xls/.csv）
- 文件 input：`#fileInput` accept=".xlsx,.xls,.csv"
- 解析后自动关闭并打开 `#importModal`

### 5.2 `#dbBackupModal` — 💾 数据库备份（新功能）
- 行号：50-63
- 用途：全量备份/恢复整个数据库
- 内含：
  - `#exportDbBtn2` — 📥 导出备份（下载 JSON）
  - `#restoreFileInput` — 选择 .json 备份文件
  - `#restoreDbBtn` — ♻ 恢复备份
  - `#restoreResult` — 恢复状态文本
- 注意：**与 `#backupModal`（旧名 `backupModal` 已删除表恢复）ID 不同不要混淆**

### 5.3 `#importModal` — 📋 配置导入
- 行号：64-78
- 用途：Excel 解析后的二次配置（选工作表、列、关键字段）
- 按钮：`#confirmImport` / `#cancelImport`

### 5.4 `#renameModal` — ✏️ 重命名
### 5.5 `#deleteModal` — ⚠️ 删除
- 行号：84-88
- 含删除确认文本 + `#confirmDelete` 按钮

### 5.6 `#syncModal` — 🔗 字段映射同步
- 行号：89-110
- 映射管理核心

### 5.7 `#recordModal` — 📋 数据库记录
- 行号：111-114

### 5.8 `#groupModal` — 📁 管理分组
- 行号：115-124
- 侧边栏表分组管理

### 5.9 `#createTableModal` — ＋ 新建数据表
- 行号：121-135
- 手动建表（列名 + 类型 + 关键字段）

### 5.10 `#aggregateModal` — 📊 多表汇总
- 行号：136-157

### 5.11 `#groupSummaryModal` — 📊 分类汇总
- 行号：161-183

### 5.12 `#hiddenRowsModal` — 👁 已隐藏的行
- 行号：184-190
- 显示 `_deleted=1` 的行
- 可逐条（`.unhide-row-btn`）或全部（`#unhideAllRowsBtn`）恢复

### 5.13 `#deletedRowsModal` — 🗃 表删除的记录
- 行号：191-197
- 显示 `_deleted=2` 的行
- 可逐条（`.undelete-row-btn`）或全部（`#undeleteAllRowsBtn`）恢复
- 注意：这是**新功能**，与原 `#backupModal` 不同

### 5.14 `#dbViewModal` — 🗄 数据库所有记录
- 行号：198-207
- 显示所有记录（含隐藏/表删除/正常），带状态标签
- 只读浏览，无操作按钮

### 5.15 `#colFuncModal` — 📋 列功能
- 行号：209-232

### 5.16 `#backupModal` — 📦 备份恢复（已删除表）【老功能】
- 行号：233-248
- 用于从 `_backup/` 目录恢复已删除表的备份
- 含 `#restoreSelBackup` / `#deleteSelBackup` 按钮
- ⚠️ **此 ID 与新 `#dbBackupModal` 不同，改代码注意区分！**

### 5.17 `#reorderModal` — 📝 调整字段顺序
- 行号：249-253

---

## 6. 全局 JS 变量

声明位置：`<script>` 标签紧随 bootstrap CDN 之后。

```
ct          = ""      当前选中的表名
cp          = 1       当前页码
sid         = ""      导入 session ID
ah          = []      导入的列头列表
pd          = []      导入预览数据
ls          = false   导入锁（防止重复请求）
ftypes      = {}      字段类型映射
_importFilename = ""  上传的文件名（用于生成默认表名）
_recordChanges  = {}  记录查看器的修改缓存
_currentKf      = ""  当前表的关键字段名
_saveTimer      = null AJAX 状态延迟计时器
_delToken       = ""   删除令牌（从 meta 读取）
_dragOn         = false 拖拽中
_dragMoved      = false 拖拽过
_rowDragStart   = null  行拖拽起始
_sel            = {}    当前选区
_selCellCache   = []    复制缓存
_hiddenModal    = null  bootstrap.Modal 实例（隐藏行弹窗）
_deletedModal   = null  bootstrap.Modal 实例（表删除弹窗）
_dbModal        = null  bootstrap.Modal 实例（数据库浏览弹窗）
_backupModal    = null  bootstrap.Modal 实例（数据库备份弹窗）
_gsModal        = null  bootstrap.Modal 实例（汇总弹窗... 实际未使用）
```

## 7. 所有 JS 函数

| 函数 | 行号 | 用途 |
|------|------|------|
| `setSaveStatus(state,msg)` | 262 | 更新保存状态指示器（saved/saving/editing） |
| `lt(name)` | 283 | 加载侧边栏表列表，可选选中某表并调用 `loadTable()` |
| `renderSidebar(sn)` | 299 | 渲染侧边栏 HTML（含分组折叠） |
| `loadTable(n)` | 418 | 设置 `ct=n` 后调用 `fp(ct,1)` |
| `fp(n,p,filters)` | 420 | 加载表数据主入口 + 隐藏列 + 隐藏计数 + 表删除计数 + 备份计数 |
| `markKeyFieldHeader()` | 463 | 在表头关键字段名后面加星号 |
| `render(d)` | 473 | 渲染表格 HTML（核心渲染逻辑） |
| `isFloat(v)` | 515 | 判断值是否为浮点数 |
| `applyFrozen()` | 422 | 根据 _frozenCols 对 th/td 加 .col-frozen 类 + 计算 left 偏移 |
| `fp(n,p,filters)` | 448 | 加 `order_field`/`order_dir` 参数传后端排序 |
| `toggleCol(f)` | 585 | 切换列隐藏/显示 |
| `renderAggregatePreview(d)` | 984 | 汇总预览渲染 |
| `posMenu(m)` | 1068 | 右键菜单定位 |
| `buildSelGrid()` | 1120 | 根据选区构建粘贴网格 |
| `doCopy()` | 1136 | 复制选中数据到缓存 |
| `doPaste()` | 1161 | 粘贴数据 |
| `applyPaste()` | 1163 | 执行粘贴写入 |
| `showToast(msg,type)` | 1207 | Toast 提示 |
| `batchUpdateCells(updates,callback)` | 1212 | 批量更新单元格 |
| `selClear()` | 1309 | 清除选区 |
| `selCols(field)` | 1316 | 选中整列 |
| `selRange(startTd,endTd)` | 1319 | 范围选择 |
| `saveCell(td,field,id,callback)` | 1552 | 保存单个单元格 |
| `displayVal(v,type,field)` | 1567 | 格式化显示值 |
| `renameCol(field)` | 1576 | 重命名字段列 |
| `showImport(d)` | 1601 | Excel 解析后的导入配置界面 |
| `updateTitle(sn)` | 1617 | 更新导入弹窗标题 |
| `rf(headers)` | 1622 | 渲染导入字段选择 |
| `rp()` | 1625 | 渲染导入预览 |
| `loadSync()` | 1634 | 加载映射列表 |
| `renderSyncList()` | 1638 | 渲染映射列表 |
| `preloadFields(src,tgt)` | 1645 | 预加载字段列表 |
| `editMapping(idx)` | 1646 | 编辑映射 |
| `showFieldPairs(pairs,srcFields,tgtFields)` | 1674 | 显示字段映射对 |
| `doVerify(storeRaw)` | 1731 | 核实验证映射数据一致性 |
| `colRowHtml(prefix,fields)` | 1788 | 列设置行的 HTML |
| `updateKeyFieldOptions()` | 1803 | 更新建表弹窗的关键字段下拉 |

---

## 8. 后端 API 完整清单

### 8.1 基础

| 行号 | 路由 | 方法 | 函数 | 参数 | 返回 | 说明 |
|------|------|------|------|------|------|------|
| 108 | `/` | GET | `index` | - | HTML | 首页渲染 `index.html`，传入 `del_token` |
| 113 | `/api/tables` | GET | `api_tables` | - | `{code,data:[{name,comment}]}` | 获取所有表 |

### 8.2 表操作

| 行号 | 路由 | 方法 | 函数 | 参数 | 说明 |
|------|------|------|------|------|------|
| 117 | `/api/tables` | POST | `api_create_table` | `{name,columns,key_field}` | 建空表，更新 manifest |
| 154 | `/api/table-groups` | GET | `api_get_groups` | - | 获取表分组 |
| 158 | `/api/table-groups` | POST | `api_save_groups` | `{groups:[...]}` | 保存表分组 |
| 168 | `/api/table/<name>/key-field` | GET | `api_get_key_field` | - | 获取关键字段 |
| 173 | `/api/table/<name>/key-field` | POST | `api_set_key_field` | `{key_field}` | 设置关键字段 |
| 190 | `/api/table/<name>` | DELETE | `api_delete_table` | `{del_token}` | 删表（含 del_token 防护） |
| 206 | `/api/table/<name>` | PUT | `api_rename_table` | `{name}` | 重命名表 |
| 226 | `/api/table/<name>/column` | PATCH | `api_rename_column` | `{old_name,new_name}` | 重命名字段（同时更新映射） |
| 249 | `/api/table/<name>/row` | POST | `api_add_row` | - | 插入一条空记录 |
| 271 | `/api/table/<name>/row/<id>` | DELETE | `api_delete_row` | - | 级联删除（关联表同步删） |
| 298 | `/api/table/<name>/row/<id>/hide` | POST | `api_hide_row` | - | 隐藏行（关键字段空则硬删） |
| 323 | `/api/table/<name>/rows/hide` | POST | `api_hide_rows` | `{ids:[]}` | 批量隐藏 |
| 340 | `/api/table/<name>/rows/unhide` | POST | `api_unhide_rows` | `{ids:[]}` | 批量恢复隐藏（空 = 全部） |
| 356 | `/api/table/<name>/row/<id>/table-delete` | POST | `api_table_delete_row` | - | 表删除：_deleted=2 |
| 369 | `/api/table/<name>/hidden-count` | GET | `api_hidden_count` | - | `{count:N}` |
| 381 | `/api/table/<name>/hidden-rows` | GET | `api_hidden_rows` | - | `_deleted=1` 行列表，带 `_seq` |
| 398 | `/api/table/<name>/deleted-rows` | GET | `api_deleted_rows` | - | `_deleted=2` 行列表，带 `_seq` |
| 415 | `/api/table/<name>/all-rows` | GET | `api_all_rows` | - | 所有记录（含隐藏/表删），带 `_del_status` |
| 433 | `/api/table/<name>/rows/un-table-delete` | POST | `api_un_table_delete_rows` | `{ids:[]}` | 恢复表删除行 |

### 8.3 列操作

| 行号 | 路由 | 方法 | 函数 | 说明 |
|------|------|------|------|------|
| 460 | `/api/table/<name>/column/hide` | POST | `api_hide_column` | 隐藏列 |
| 470 | `/api/table/<name>/column/unhide` | POST | `api_unhide_column` | 取消隐藏列 |
| 482 | `/api/table/<name>/hidden-cols` | GET | `api_hidden_cols` | 获取隐藏列列表 |
| 488 | `/api/table/<name>/column` | POST | `api_add_column` | 插入新列（after 参数） |
| 505 | `/api/table/<name>/column/<name>/type` | PUT | `api_set_column_type` | 修改列类型 |
| 518 | `/api/table/<name>/reorder-columns` | POST | `api_reorder_columns` | 调整字段顺序 |
| 553 | `/api/table/<name>/column/<name>` | DELETE | `api_delete_column` | 删除列 |
| 563 | `/api/table/<name>/column/<name>/values` | GET | `api_column_values` | 获取列的唯一直（支持级联筛选） |

### 8.4 数据操作

| 行号 | 路由 | 方法 | 函数 | 说明 |
|------|------|------|------|------|
| 579 | `/api/table/<name>/lookup` | GET | `api_lookup` | 按字段值查找（自动补全） |
| 591 | `/api/table/<name>/record/<id>` | GET | `api_view_record` | 查看记录所有字段+关联表 |
| 621 | `/api/table/batch-update` | POST | `api_batch_update` | 批量更新字段值 |
| 638 | `/api/table/<name>/export` | GET | `api_export_table` | 导出 Excel（公文格式） |
| 709 | `/api/table/<name>` | PATCH | `api_update_cell` | 更新单个单元格 |
| 769 | `/api/table/<name>` | GET | `api_table` | 获取表数据（分页/搜索/排序/筛选） |

### 8.5 同步映射

| 行号 | 路由 | 方法 | 函数 | 说明 |
|------|------|------|------|------|
| 794 | `/api/sync/mappings` | GET | `api_get_mappings` | 获取所有映射 |
| 798 | `/api/sync/mappings` | POST | `api_save_mappings` | 保存映射列表 |
| 805 | `/api/sync/schema/<name>` | GET | `api_sync_schema` | 获取非主键字段列表 |
| 813 | `/api/sync/verify` | POST | `api_sync_verify` | 核实两表映射数据一致性 |
| 868 | `/api/sync/auto-fill` | POST | `api_auto_fill` | 关键字段编辑后自动补填 |
| 890 | `/api/sync/backfill` | POST | `api_sync_backfill` | 批量补填空字段 |

### 8.6 剪贴板

| 行号 | 路由 | 方法 | 函数 | 说明 |
|------|------|------|------|------|
| 942 | `/api/clipboard/copy` | POST | `api_clipboard_copy` | 复制选中数据到服务端缓存 |
| 956 | `/api/clipboard/paste` | POST | `api_clipboard_paste` | 粘贴数据到目标区域 |
| 1065 | `/api/clipboard/clear` | POST | `api_clipboard_clear` | 清空剪贴板 |
| 1071 | `/api/clipboard` | GET | `api_clipboard_status` | 获取剪贴板状态 |

### 8.7 汇总

| 行号 | 路由 | 方法 | 函数 | 说明 |
|------|------|------|------|------|
| 1085 | `/api/aggregate/preview` | POST | `api_aggregate_preview` | 预览多表汇总结果 |
| 1229 | `/api/aggregate/create` | POST | `api_aggregate_create` | 创建汇总表 + 自动建立映射 |
| 1306 | `/api/table/<name>/group-summary` | POST | `api_group_summary` | 分组汇总存为新表 |

### 8.8 备份

| 行号 | 路由 | 方法 | 函数 | 说明 |
|------|------|------|------|------|
| 1367 | `/api/backup/list` | GET | `api_backup_list` | 列出 _backup/ 备份文件 |
| 1395 | `/api/backup/restore` | POST | `api_backup_restore` | 从备份恢复表 |
| 1435 | `/api/backup/delete` | POST | `api_backup_delete` | 删除备份文件 |
| 1454 | `/api/database/export` | GET | `api_db_export` | 导出全库 JSON |
| 1497 | `/api/database/import` | POST | `api_db_import` | 从 JSON 恢复全库 |

### 8.9 上传/导入

| 行号 | 路由 | 方法 | 函数 | 说明 |
|------|------|------|------|------|
| 1524 | `/api/upload/parse` | POST | `api_upload_parse` | 解析 Excel/CSV/ET 文件 |
| 1570 | `/api/upload/select_sheet` | POST | `api_upload_select_sheet` | 选择工作表 |
| 1580 | `/api/upload/set_header_rows` | POST | `api_upload_set_header_rows` | 设置表头行范围 |
| 1634 | `/api/upload/import` | POST | `api_upload_import` | 确认导入（关键字段 + 列筛选） |

---

## 9. `_deleted` 字段状态机

```
                ┌──────────────┐
                │ _deleted = 0 │  ← 正常记录（主表可见）
                │  或 NULL     │
                └──────┬───────┘
                       │
            ┌──────────┼──────────┐
            ▼                    ▼
   ┌──────────────┐    ┌──────────────────┐
   │_deleted = 1  │    │ _deleted = 2     │
   │  隐藏行      │    │  表删除          │
   │  #hiddenBadge│    │  #deletedBadge   │
   │  可恢复 → 0  │    │  可恢复 → 0     │
   └──────────────┘    └──────────────────┘
```

恢复路径：
- `_deleted=1` → POST `/api/table/<name>/rows/unhide`
- `_deleted=2` → POST `/api/table/<name>/rows/un-table-delete`

硬删除：关键字段为空时 `api_hide_row` 会直接 DELETE FROM 数据库（不可恢复）。

---

## 10. 右键菜单结构

| 菜单 | ID | 触发器 | 选项 |
|------|----|--------|------|
| 单元格菜单 | `#cellMenu` | 右键 td.editable | 复制 / 粘贴 / 删除 |
| 列菜单 | `#colMenu` | 右键 th | 重命名 / 插入列(前/后) / 删除列 / 修改类型 / 隐藏列 / 清除筛选 / 筛选 |
| 行菜单 | `#rowMenu` | 右键 td:first-child | 插入行(上/下) / 删除行 / 隐藏行 / 表删除 / 查看记录 |

---

## 11. 选区和编辑交互

### 选区模式
- **多选**：`Ctrl+点击` 单元格 → 选区模式
- **范围**：`Shift+点击` → 从起点到点击的矩形范围
- **整列**：点击列头
- **整行**：点击行序号列（td:first-child）

### 编辑
- **双击** td.editable → 出现 `input.cell-editor`（类型自动匹配：number/日期/文本）
- **`Tab`** → 跳到下一格
- **`Enter`** → 跳到下一行
- **`Esc`** → 取消编辑
- **blur** → 自动保存（调用 `saveCell` → PATCH /api/table/<name>）

### 粘贴
- `Ctrl+V` → 解析剪贴板数据 → 从锚点展开（Excel 风格自动扩展）
- 后端 API `/api/clipboard/paste` 处理

### 拖拽
- **单元格拖拽选中**：`mousedown` td.editable → `mousemove` 选范围
- **行拖拽移动**：`mousedown` td:first-child → 拖拽序号列

---

## 12. 自动备份（删表时）

每次 DELETE `/api/table/<name>` 时：
1. `_backup_table(table_name)` → 备份到 `_backup/<表名>_<时间戳>.json`
2. 再执行 DROP TABLE
3. 更新 `_backup/_manifest.json`

每次 CREATE TABLE 或 IMPORT 时：
1. `_save_table_manifest()` → 更新 manifest

---

## 13. 配置文件详解

### `_key_fields.json`
```json
{"表名": "字段名", ...}
```
关键字段用于导入去重和自动补填。

### `_hidden_columns.json`
```json
{"表名": ["列名", ...]}
```

### `_sync_mappings.json`
```json
[{
  "src_table": "源表名",
  "tgt_table": "目标表名",
  "kf": "关键字段名",
  "pairs": [{"src": "源字段", "tgt": "目标字段"}, ...]
}]
```

### `_table_groups.json`
```json
[{"name": "分组名", "tables": ["表名", ...]}]
```

---

## 14. 数据库表

### 窄路面拓宽改造表（主表）
- 26 个字段（含 `id`、`_deleted`）
- 核心字段：`项目名称`
- 78 条记录

### 项目总表
- 34 个字段（含 `id`、`_deleted`）
- 核心字段：`项目名称`
- 78 条记录

### 测试2
- 2 个字段（`id`, `col_12`）
- 0 条记录

---

## 15. 删除令牌防护（`del_token`）

服务端 `_DEL_TOKEN = os.urandom(8).hex()` 每次启动随机生成。
页面 `<meta name="del-token" content="...">` 嵌入。
所有 DELETE API（`api_delete_table`）要求客户端提供匹配的 `del_token`。

---

## 16. ⚠️ 修改铁律

1. **改代码前先读本文件**，确认改动不会影旧功能
2. **新增 Modal ID 全局唯一**：搜索 `id="xxx"` 确认无冲突
3. **JS 括号平衡**：改完后必须验证 opens=closes
4. **不残留旧代码**：替换功能时彻底删除旧 handler body
5. **不随意动已有功能的按钮/弹窗结构**
6. **改完必须重启 Flask**：`taskkill /f /im python.exe` → 再启动
7. **不改 backupModal（老）**：`id="backupModal"` 是删表备份恢复，`id="dbBackupModal"` 是全库备份恢复，互不干扰
8. **不改 uploadBtn 文件类型**：`accept=".xlsx,.xls,.csv"`，JSON 走 `#dbBackupModal`
9. **推 GitHub 前先 `GET` 远端 tree**：增量同步，不盲推全量替换
10. **调试文件不放桌面**：放 `E:\reasonix-data\projects\road-ledger\_tmp\`

---

## 17. 修改历史

| 日期 | 修改内容 |
|------|----------|
| 2026-05-30 | 新增 `#dbBackupModal` 数据库备份/恢复弹窗（`#backupManageBtn`） |
| 2026-05-30 | 新增 `#deletedBadge` + `#deletedRowsModal` 表删除记录管理 |
| 2026-05-30 | 新增 `#dbViewBtn` + `#dbViewModal` 数据库全记录浏览 |
| 2026-05-30 | 修复 `backupModal` ID 冲突（老 `#backupModal` 删表恢复，新 `#dbBackupModal` 全库备份） |
| 2026-05-30 | 修复 `restoreBackupBtn` 旧 handler 残留导致 JS 断裂 |
| 2026-05-30 | 创建本 `PROJECT_MAP.md` |
| 2026-05-30 | 新增列冻结（右键列头 → 冻结此列/取消冻结） |
| 2026-05-30 | 行号加 tooltip 显示数据库 ID + 侧边栏表名加 tooltip 显示全名 |
| 2026-05-30 | 新增排序指示器（点击表头排序，显示 ↑/↓，三态：升→降→无） |

---

## 18. 尚未描述的功能（待补充）

如需更详细的说明，以下部分可读取文件展开：
- `db.py`：`get_page`、`import_tables`、`export_all_tables` 的实现细节
- `config.py`：数据库连接参数
- `style.css`：自定义样式细节
- `push_github.py`：GitHub 推送脚本
- `start.py` / `start.bat`：启动逻辑
